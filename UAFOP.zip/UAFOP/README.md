# Smart Planner (MVP)

A local-first family planner with a shared, role-based chat. Each person runs
the app on their own device; tasks and the calendar are personal, while chat is
shared across the family in real time.

## What it does

- **Today** — your landing page. Shows today's tasks, or an "All tasks
  complete!" message when there are none, plus an **Add event** button.
- **Calendar** — a month view of the *same* tasks. Adding or removing a task
  anywhere updates the calendar automatically, because tasks and calendar
  events are one and the same record (no syncing, no drift).
- **Chat** — role-based channels that are created and joined **automatically**:
  - `Family` — everyone in the family.
  - `Parents` — parents only.
- **Family** (parents only) — register a child or relative. Each gets an
  **invite code** to claim their account on their own device, at which point
  they're auto-added to the right channels.

## Tech

- Frontend: React + Vite + Tailwind CSS
- Backend: Node + Express + `ws` (WebSocket) + SQLite (`better-sqlite3`)
- One server serves the built UI and the API/WebSocket on a single port.

## Run it

Requires Node 18+ (Node 20+ recommended).

```bash
npm install
npm start
```

`npm start` builds the UI and starts the server on
**http://localhost:3001**. Open that URL in a browser.

### Try the parent ↔ child flow

1. Open the app, choose **I'm a parent**, enter your name → you land on Today.
2. Go to the **Family** tab → add a member (e.g. a child) → copy their
   **invite code**.
3. Open the app in a second browser/device → choose **I have a code** → paste
   the code → that device is now the child.
4. Open **Chat** on both → messages appear live in the `Family` channel.

> Two devices on the same network: start the server on one machine, then on the
> other device open `http://<that-machine-ip>:3001`.

## Development

```bash
npm run dev
```

Runs the API on `:3001` and the Vite dev server on `:5173` with hot reload
(Vite proxies `/api` and `/ws` to the backend).

## Data

Everything is stored in `data.sqlite` in the project root. Delete that file to
reset to a clean slate.

## Project layout

```
server/
  index.js      Express REST API + WebSocket chat + static hosting
  db.js         SQLite schema
  channels.js   Auto channel creation + role-based enrollment
src/
  App.jsx       Session, shared task state, tab navigation
  api.js        REST client + WebSocket helper
  dateutils.js  Local-date helpers + month grid
  components/   Onboarding, Today, Calendar, Chat, Members, AddEvent
```

## Notes / next steps

- Auth is intentionally lightweight (name + invite code) for the MVP. For
  production add real accounts/passwords or an OAuth provider.
- Chat history loads the last 200 messages per channel.
- Natural extensions: shared family calendar view, task reminders/push
  notifications, editing events, and per-channel read state.

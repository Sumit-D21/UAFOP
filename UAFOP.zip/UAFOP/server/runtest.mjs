// Starts the server in-process (no background job), runs the smoke checks,
// then exits. Single foreground process = clean for any shell.
import fs from "fs";

const PORT = process.env.PORT || "3790";
process.env.PORT = PORT;
const OUT = process.env.OUT || "/tmp/test.out";
fs.writeFileSync(OUT, "");
const log = (s) => fs.appendFileSync(OUT, s + "\n");
const assert = (c, msg) => {
  log((c ? "ok - " : "FAIL: ") + msg);
  if (!c) throw new Error("FAIL: " + msg);
};

process.on("unhandledRejection", (e) => {
  log("ERROR: " + (e?.stack || e));
  process.exit(1);
});

// Boot the real server.
await import("./index.js");
await new Promise((r) => setTimeout(r, 500));

const BASE = `http://localhost:${PORT}`;
const j = async (m, p, b) => {
  const r = await fetch(BASE + p, {
    method: m,
    headers: { "Content-Type": "application/json" },
    body: b ? JSON.stringify(b) : undefined,
  });
  const d = await r.json();
  if (!r.ok) throw new Error(`${m} ${p} -> ${r.status} ${JSON.stringify(d)}`);
  return d;
};

const today = new Date().toISOString().slice(0, 10);

const { profile: parent } = await j("POST", "/api/register", {
  name: "Alex",
  familyName: "Rivera",
});
assert(parent.role === "parent", "parent registered");

const pch = (await j("GET", `/api/channels?profileId=${parent.id}`)).channels;
assert(pch.length === 2, "parent in 2 channels (Family + Parents)");
assert(
  pch.some((c) => c.name === "Family") && pch.some((c) => c.name === "Parents"),
  "channels are Family + Parents"
);

const { profile: child, inviteCode } = await j("POST", "/api/members", {
  parentProfileId: parent.id,
  name: "Jamie",
  role: "child",
});
assert(!!inviteCode, "child got invite code " + inviteCode);

const cch = (await j("GET", `/api/channels?profileId=${child.id}`)).channels;
assert(cch.length === 1 && cch[0].name === "Family", "child in Family only");

const joined = (await j("POST", "/api/join", { inviteCode })).profile;
assert(joined.id === child.id && joined.claimed, "child claimed via code");

const { task } = await j("POST", "/api/tasks", {
  profileId: parent.id,
  title: "Dentist",
  date: today,
  time: "09:30",
});
const todays = (await j("GET", `/api/tasks?profileId=${parent.id}&date=${today}`)).tasks;
assert(todays.length === 1 && todays[0].title === "Dentist", "task shows today");
assert(
  (await j("GET", `/api/tasks?profileId=${parent.id}`)).tasks.length === 1,
  "same task in calendar list"
);
await j("PATCH", `/api/tasks/${task.id}`, { done: true });
assert(
  (await j("GET", `/api/tasks?profileId=${parent.id}`)).tasks[0].done === true,
  "task toggles done"
);
await j("DELETE", `/api/tasks/${task.id}`);
assert(
  (await j("GET", `/api/tasks?profileId=${parent.id}`)).tasks.length === 0,
  "task removed -> calendar empty"
);

// Real-time chat
const familyChannel = pch.find((c) => c.name === "Family").id;
const { WebSocket } = await import("ws");
const wsUrl = `ws://localhost:${PORT}/ws?profileId=`;
const childWs = new WebSocket(wsUrl + child.id);
const parentWs = new WebSocket(wsUrl + parent.id);
const opened = (ws, name) =>
  new Promise((res, rej) => {
    ws.on("open", res);
    ws.on("error", (e) => rej(new Error(`${name} ws: ${e.message}`)));
    setTimeout(() => rej(new Error(`${name} ws open timeout`)), 3000);
  });
await Promise.all([opened(childWs, "child"), opened(parentWs, "parent")]);
assert(true, "both websockets connected");

const received = new Promise((res) =>
  childWs.on("message", (raw) => res(JSON.parse(raw.toString())))
);
parentWs.send(JSON.stringify({ type: "send", channelId: familyChannel, body: "Hi Jamie!" }));
const msg = await Promise.race([
  received,
  new Promise((_, rej) => setTimeout(() => rej(new Error("chat timeout")), 3000)),
]);
assert(msg.message.body === "Hi Jamie!", "child received parent's live message");
assert(msg.message.senderName === "Alex", "message carries sender name + role");

log("\nALL CHECKS PASSED");
process.exit(0);

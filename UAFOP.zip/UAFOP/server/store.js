import fs from "fs";
import { fileURLToPath } from "url";
import path from "path";

// Tiny dependency-free persistence layer. All data lives in a single JSON file
// next to the project. This keeps the MVP zero-config — no native modules, no
// database server, runs anywhere Node runs. For production you'd swap this for
// Postgres/SQLite, but the access pattern below is deliberately simple so that
// migration is mechanical.

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataPath = path.join(__dirname, "..", "data.json");

const empty = {
  families: [],
  profiles: [],
  channels: [],
  channel_members: [], // { channel_id, profile_id }
  messages: [],
  tasks: [],
};

let db;
try {
  db = { ...empty, ...JSON.parse(fs.readFileSync(dataPath, "utf8")) };
} catch {
  db = structuredClone(empty);
}

let saveTimer = null;
export function save() {
  // Debounced write so a burst of mutations doesn't thrash the disk.
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fs.writeFileSync(dataPath, JSON.stringify(db, null, 2));
  }, 50);
}

// Flush synchronously on exit so nothing is lost.
process.on("exit", () => {
  try {
    fs.writeFileSync(dataPath, JSON.stringify(db, null, 2));
  } catch {}
});
process.on("SIGINT", () => process.exit(0));
process.on("SIGTERM", () => process.exit(0));

export default db;

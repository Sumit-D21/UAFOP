import { nanoid } from "nanoid";
import db, { save } from "./store.js";

const now = () => new Date().toISOString();

// Create the default channels for a brand-new family.
// Rule: every family gets a "Family" channel (everyone) and a "Parents"
// channel (parents only). New channels are created automatically here —
// callers never create channels by hand.
export function createDefaultChannels(familyId) {
  db.channels.push({
    id: nanoid(),
    family_id: familyId,
    name: "Family",
    kind: "family",
    created_at: now(),
  });
  db.channels.push({
    id: nanoid(),
    family_id: familyId,
    name: "Parents",
    kind: "parents",
    created_at: now(),
  });
  save();
}

// Auto-enroll a profile into the channels appropriate for its role. Runs
// whenever a profile is created (parent, child, or relative), so channel
// membership is always maintained automatically.
export function enrollProfileInChannels(profile) {
  const channels = db.channels.filter((c) => c.family_id === profile.family_id);
  for (const ch of channels) {
    const joins =
      ch.kind === "family" || (ch.kind === "parents" && profile.role === "parent");
    if (joins && !isMember(ch.id, profile.id)) {
      db.channel_members.push({ channel_id: ch.id, profile_id: profile.id });
    }
  }
  save();
}

export function channelsForProfile(profileId) {
  const ids = new Set(
    db.channel_members
      .filter((m) => m.profile_id === profileId)
      .map((m) => m.channel_id)
  );
  return db.channels
    .filter((c) => ids.has(c.id))
    .sort((a, b) => a.created_at.localeCompare(b.created_at));
}

export function isMember(channelId, profileId) {
  return db.channel_members.some(
    (m) => m.channel_id === channelId && m.profile_id === profileId
  );
}

export function membersOfChannel(channelId) {
  return db.channel_members
    .filter((m) => m.channel_id === channelId)
    .map((m) => m.profile_id);
}

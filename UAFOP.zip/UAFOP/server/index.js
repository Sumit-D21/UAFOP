import express from "express";
import http from "http";
import { WebSocketServer } from "ws";
import { customAlphabet, nanoid } from "nanoid";
import { fileURLToPath } from "url";
import path from "path";
import fs from "fs";

import db, { save } from "./store.js";
import {
  createDefaultChannels,
  enrollProfileInChannels,
  channelsForProfile,
  isMember,
  membersOfChannel,
} from "./channels.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3001;
const now = () => new Date().toISOString();
const inviteCode = customAlphabet("ABCDEFGHJKLMNPQRSTUVWXYZ23456789", 6);

const app = express();
app.use(express.json());

// ---------- helpers ----------
const getProfile = (id) => db.profiles.find((p) => p.id === id);

const publicProfile = (p) =>
  p && {
    id: p.id,
    familyId: p.family_id,
    parentId: p.parent_id,
    name: p.name,
    role: p.role,
    inviteCode: p.invite_code,
    claimed: !!p.claimed,
  };

const serializeTask = (t) => ({
  id: t.id,
  profileId: t.profile_id,
  title: t.title,
  date: t.date,
  time: t.time,
  done: !!t.done,
});

const serializeMessage = (m) => ({
  id: m.id,
  channelId: m.channel_id,
  senderId: m.sender_id,
  senderName: m.sender_name,
  senderRole: m.sender_role,
  body: m.body,
  createdAt: m.created_at,
});

// ---------- auth / accounts ----------

// Register the first user (a parent). Creates the family + default channels.
app.post("/api/register", (req, res) => {
  const { name, familyName } = req.body || {};
  if (!name) return res.status(400).json({ error: "name is required" });

  const familyId = nanoid();
  db.families.push({
    id: familyId,
    name: familyName || `${name}'s family`,
    created_at: now(),
  });

  const profile = {
    id: nanoid(),
    family_id: familyId,
    parent_id: null,
    name,
    role: "parent",
    invite_code: null,
    claimed: 1,
    created_at: now(),
  };
  db.profiles.push(profile);
  save();

  createDefaultChannels(familyId); // channels auto-created
  enrollProfileInChannels(profile); // parent auto-enrolled

  res.json({ profile: publicProfile(profile) });
});

// A parent registers a child or relative. Returns an invite code that the
// new member uses to claim the account on their own device.
app.post("/api/members", (req, res) => {
  const { parentProfileId, name, role } = req.body || {};
  const parent = getProfile(parentProfileId);
  if (!parent || parent.role !== "parent")
    return res.status(403).json({ error: "must be a parent to add members" });
  if (!name || !["child", "relative"].includes(role))
    return res.status(400).json({ error: "name and a valid role are required" });

  const profile = {
    id: nanoid(),
    family_id: parent.family_id,
    parent_id: parent.id,
    name,
    role,
    invite_code: inviteCode(),
    claimed: 0,
    created_at: now(),
  };
  db.profiles.push(profile);
  save();

  enrollProfileInChannels(profile); // auto-added to the right channels

  res.json({ profile: publicProfile(profile), inviteCode: profile.invite_code });
});

// Claim an account on a second device using the invite code.
app.post("/api/join", (req, res) => {
  const { inviteCode: code } = req.body || {};
  if (!code) return res.status(400).json({ error: "invite code is required" });
  const profile = db.profiles.find(
    (p) => p.invite_code === String(code).trim().toUpperCase()
  );
  if (!profile) return res.status(404).json({ error: "invalid invite code" });

  profile.claimed = 1;
  save();
  res.json({ profile: publicProfile(profile) });
});

app.get("/api/profile/:id", (req, res) => {
  const p = getProfile(req.params.id);
  if (!p) return res.status(404).json({ error: "not found" });
  const family = db.families.find((f) => f.id === p.family_id);
  res.json({ profile: publicProfile(p), family });
});

// Family roster (used by the parent's "manage members" view).
app.get("/api/family/:familyId/members", (req, res) => {
  const rows = db.profiles
    .filter((p) => p.family_id === req.params.familyId)
    .sort((a, b) => a.created_at.localeCompare(b.created_at));
  res.json({ members: rows.map(publicProfile) });
});

// ---------- tasks / calendar ----------

// List tasks for a profile. Optional ?date=YYYY-MM-DD filters to one day
// (the "today" list); without it you get everything (the calendar).
app.get("/api/tasks", (req, res) => {
  const { profileId, date } = req.query;
  if (!profileId) return res.status(400).json({ error: "profileId required" });
  let rows = db.tasks.filter((t) => t.profile_id === profileId);
  if (date) rows = rows.filter((t) => t.date === date);
  rows = rows.sort(
    (a, b) =>
      a.date.localeCompare(b.date) ||
      (a.time || "99:99").localeCompare(b.time || "99:99")
  );
  res.json({ tasks: rows.map(serializeTask) });
});

app.post("/api/tasks", (req, res) => {
  const { profileId, title, date, time } = req.body || {};
  if (!profileId || !title || !date)
    return res.status(400).json({ error: "profileId, title and date required" });
  const task = {
    id: nanoid(),
    profile_id: profileId,
    title,
    date,
    time: time || null,
    done: 0,
    created_at: now(),
  };
  db.tasks.push(task);
  save();
  res.json({ task: serializeTask(task) });
});

app.patch("/api/tasks/:id", (req, res) => {
  const { done, title, date, time } = req.body || {};
  const t = db.tasks.find((x) => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: "not found" });
  if (done !== undefined) t.done = done ? 1 : 0;
  if (title !== undefined) t.title = title;
  if (date !== undefined) t.date = date;
  if (time !== undefined) t.time = time || null;
  save();
  res.json({ task: serializeTask(t) });
});

app.delete("/api/tasks/:id", (req, res) => {
  const i = db.tasks.findIndex((t) => t.id === req.params.id);
  if (i !== -1) db.tasks.splice(i, 1);
  save();
  res.json({ ok: true });
});

// ---------- channels / messages ----------

app.get("/api/channels", (req, res) => {
  const { profileId } = req.query;
  if (!profileId) return res.status(400).json({ error: "profileId required" });
  res.json({ channels: channelsForProfile(profileId) });
});

app.get("/api/channels/:id/messages", (req, res) => {
  const rows = db.messages
    .filter((m) => m.channel_id === req.params.id)
    .sort((a, b) => a.created_at.localeCompare(b.created_at))
    .slice(-200)
    .map((m) => {
      const sender = getProfile(m.sender_id) || {};
      return serializeMessage({
        ...m,
        sender_name: sender.name,
        sender_role: sender.role,
      });
    });
  res.json({ messages: rows });
});

// ---------- static frontend (production) ----------
const distDir = path.join(__dirname, "..", "dist");
if (fs.existsSync(distDir)) {
  app.use(express.static(distDir));
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api")) return next();
    res.sendFile(path.join(distDir, "index.html"));
  });
}

// ---------- WebSocket: real-time chat ----------
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

// profileId -> Set<socket>
const sockets = new Map();

wss.on("connection", (ws, req) => {
  const url = new URL(req.url, "http://localhost");
  const profileId = url.searchParams.get("profileId");
  if (!profileId || !getProfile(profileId)) {
    ws.close();
    return;
  }
  if (!sockets.has(profileId)) sockets.set(profileId, new Set());
  sockets.get(profileId).add(ws);

  ws.on("message", (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return;
    }
    if (msg.type === "send") {
      const { channelId, body } = msg;
      if (!body || !channelId || !isMember(channelId, profileId)) return;

      const record = {
        id: nanoid(),
        channel_id: channelId,
        sender_id: profileId,
        body: String(body).slice(0, 2000),
        created_at: now(),
      };
      db.messages.push(record);
      save();

      const sender = getProfile(profileId);
      const payload = JSON.stringify({
        type: "message",
        message: serializeMessage({
          ...record,
          sender_name: sender.name,
          sender_role: sender.role,
        }),
      });

      // Broadcast to every connected member of the channel.
      for (const memberId of membersOfChannel(channelId)) {
        const set = sockets.get(memberId);
        if (!set) continue;
        for (const s of set) if (s.readyState === s.OPEN) s.send(payload);
      }
    }
  });

  ws.on("close", () => {
    const set = sockets.get(profileId);
    if (set) {
      set.delete(ws);
      if (set.size === 0) sockets.delete(profileId);
    }
  });
});

server.listen(PORT, () => {
  console.log(`Smart Planner running on http://localhost:${PORT}`);
});

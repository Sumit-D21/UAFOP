import { useState } from "react";
import { api } from "../api.js";

// First-run screen: either register as a parent (creates a new family) or
// join an existing family with an invite code sent by a parent.
export default function Onboarding({ onReady }) {
  const [mode, setMode] = useState("register"); // register | join
  const [name, setName] = useState("");
  const [familyName, setFamilyName] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const data =
        mode === "register"
          ? await api.register(name.trim(), familyName.trim())
          : await api.join(code.trim());
      onReady(data.profile);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-full flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
        <h1 className="text-2xl font-bold text-slate-900">Smart Planner</h1>
        <p className="text-slate-500 mt-1">
          Plan your day and stay in sync with your family.
        </p>

        <div className="mt-6 grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setMode("register")}
            className={`py-2 rounded-md text-sm font-medium ${
              mode === "register" ? "bg-white shadow text-brand-700" : "text-slate-500"
            }`}
          >
            I'm a parent
          </button>
          <button
            onClick={() => setMode("join")}
            className={`py-2 rounded-md text-sm font-medium ${
              mode === "join" ? "bg-white shadow text-brand-700" : "text-slate-500"
            }`}
          >
            I have a code
          </button>
        </div>

        <form onSubmit={submit} className="mt-6 space-y-4">
          {mode === "register" ? (
            <>
              <Field label="Your name">
                <input
                  className="input"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Alex"
                  required
                />
              </Field>
              <Field label="Family name (optional)">
                <input
                  className="input"
                  value={familyName}
                  onChange={(e) => setFamilyName(e.target.value)}
                  placeholder="e.g. The Rivera Family"
                />
              </Field>
            </>
          ) : (
            <Field label="Invite code">
              <input
                className="input uppercase tracking-widest"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="ABC123"
                required
              />
            </Field>
          )}

          {error && <p className="text-sm text-red-600">{error}</p>}

          <button
            type="submit"
            disabled={busy}
            className="w-full bg-brand-600 hover:bg-brand-700 text-white font-medium py-2.5 rounded-lg disabled:opacity-60"
          >
            {busy ? "Please wait…" : mode === "register" ? "Create my planner" : "Join family"}
          </button>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-slate-700">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}

import { useEffect, useState } from "react";
import { api } from "../api.js";

// Parent-only screen: register a child or relative and hand them an invite
// code to claim the account on their own device. Channel membership is set up
// automatically by the server when the member is created.
export default function MembersView({ profile }) {
  const [members, setMembers] = useState([]);
  const [name, setName] = useState("");
  const [role, setRole] = useState("child");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    const d = await api.members(profile.familyId);
    setMembers(d.members);
  }
  useEffect(() => {
    load();
  }, [profile.familyId]);

  async function add(e) {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    setError("");
    try {
      await api.addMember(profile.id, name.trim(), role);
      setName("");
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-slate-900">Family</h2>
      <p className="text-slate-500">
        Add a child or relative, then share their code so they can join from
        their own device.
      </p>

      <form
        onSubmit={add}
        className="mt-5 bg-white border border-slate-200 rounded-2xl p-4 flex flex-wrap gap-3 items-end"
      >
        <label className="flex-1 min-w-[10rem]">
          <span className="text-sm font-medium text-slate-700">Name</span>
          <input
            className="input mt-1"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Jamie"
          />
        </label>
        <label>
          <span className="text-sm font-medium text-slate-700">Role</span>
          <select
            className="input mt-1"
            value={role}
            onChange={(e) => setRole(e.target.value)}
          >
            <option value="child">Child</option>
            <option value="relative">Relative</option>
          </select>
        </label>
        <button
          disabled={busy}
          className="bg-brand-600 hover:bg-brand-700 text-white font-medium px-4 py-2 rounded-lg disabled:opacity-60"
        >
          Add member
        </button>
      </form>
      {error && <p className="text-sm text-red-600 mt-2">{error}</p>}

      <div className="mt-6 space-y-2">
        {members.map((m) => (
          <div
            key={m.id}
            className="flex items-center justify-between bg-white border border-slate-200 rounded-xl px-4 py-3"
          >
            <div>
              <p className="font-medium text-slate-800">
                {m.name}
                {m.id === profile.id && (
                  <span className="text-xs text-slate-400"> (you)</span>
                )}
              </p>
              <p className="text-xs text-slate-400 capitalize">{m.role}</p>
            </div>
            {m.role !== "parent" &&
              (m.claimed ? (
                <span className="text-xs text-green-600 font-medium">
                  Joined ✓
                </span>
              ) : (
                <div className="text-right">
                  <p className="text-xs text-slate-400">Invite code</p>
                  <p className="font-mono font-semibold tracking-widest text-brand-700">
                    {m.inviteCode}
                  </p>
                </div>
              ))}
          </div>
        ))}
      </div>
    </div>
  );
}

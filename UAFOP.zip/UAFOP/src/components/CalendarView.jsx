import { useMemo, useState } from "react";
import { monthGrid, ymd, todayStr, prettyTime } from "../dateutils.js";

// Month calendar. Reads the SAME tasks array as the Today view, so adding or
// removing a task anywhere updates the calendar automatically. Click a day to
// add an event on that date or review what's scheduled.
export default function CalendarView({ tasks, onAddOnDate, onToggle, onDelete }) {
  const [view, setView] = useState(new Date());
  const [selected, setSelected] = useState(todayStr());

  const { cells, monthName, year, month } = useMemo(
    () => monthGrid(view),
    [view]
  );

  // Map of date -> tasks for quick lookup while rendering.
  const byDate = useMemo(() => {
    const m = {};
    for (const t of tasks) (m[t.date] ||= []).push(t);
    return m;
  }, [tasks]);

  const today = todayStr();
  const selectedTasks = (byDate[selected] || []).sort((a, b) =>
    (a.time || "99").localeCompare(b.time || "99")
  );

  const shift = (delta) =>
    setView(new Date(view.getFullYear(), view.getMonth() + delta, 1));

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-900">
          {monthName} {year}
        </h2>
        <div className="flex gap-1">
          <NavBtn onClick={() => shift(-1)}>‹</NavBtn>
          <NavBtn onClick={() => setView(new Date())}>Today</NavBtn>
          <NavBtn onClick={() => shift(1)}>›</NavBtn>
        </div>
      </div>

      <div className="mt-4 bg-white border border-slate-200 rounded-2xl p-3">
        <div className="grid grid-cols-7 text-center text-xs font-medium text-slate-400 mb-1">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
            <div key={d} className="py-1">{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {cells.map((d) => {
            const key = ymd(d);
            const inMonth = d.getMonth() === month;
            const items = byDate[key] || [];
            const isSelected = key === selected;
            const isToday = key === today;
            return (
              <button
                key={key}
                onClick={() => setSelected(key)}
                className={`h-16 rounded-lg border text-left p-1.5 align-top transition
                  ${isSelected ? "border-brand-500 ring-2 ring-brand-100" : "border-transparent hover:border-slate-200"}
                  ${inMonth ? "bg-slate-50" : "bg-white text-slate-300"}`}
              >
                <div
                  className={`text-xs font-semibold inline-flex h-5 w-5 items-center justify-center rounded-full
                    ${isToday ? "bg-brand-600 text-white" : inMonth ? "text-slate-600" : "text-slate-300"}`}
                >
                  {d.getDate()}
                </div>
                {items.length > 0 && (
                  <div className="mt-1 flex gap-0.5">
                    {items.slice(0, 3).map((t) => (
                      <span
                        key={t.id}
                        className={`h-1.5 w-1.5 rounded-full ${
                          t.done ? "bg-slate-300" : "bg-brand-500"
                        }`}
                      />
                    ))}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between">
        <h3 className="font-semibold text-slate-800">
          {new Date(selected + "T00:00:00").toLocaleDateString(undefined, {
            weekday: "long",
            month: "long",
            day: "numeric",
          })}
        </h3>
        <button
          onClick={() => onAddOnDate(selected)}
          className="text-sm bg-brand-600 hover:bg-brand-700 text-white px-3 py-1.5 rounded-lg"
        >
          + Add on this day
        </button>
      </div>

      <div className="mt-3 space-y-2">
        {selectedTasks.length === 0 ? (
          <p className="text-slate-400 text-sm">Nothing scheduled.</p>
        ) : (
          selectedTasks.map((t) => (
            <div
              key={t.id}
              className="flex items-center gap-3 bg-white border border-slate-200 rounded-xl px-4 py-2.5"
            >
              <input
                type="checkbox"
                checked={t.done}
                onChange={() => onToggle(t)}
                className="h-4 w-4 rounded accent-brand-600"
              />
              <span
                className={`flex-1 text-sm ${
                  t.done ? "line-through text-slate-400" : "text-slate-700"
                }`}
              >
                {t.title}
              </span>
              {t.time && (
                <span className="text-xs text-slate-400">{prettyTime(t.time)}</span>
              )}
              <button
                onClick={() => onDelete(t)}
                className="text-slate-400 hover:text-red-500 text-xs"
              >
                Remove
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function NavBtn({ children, onClick }) {
  return (
    <button
      onClick={onClick}
      className="px-3 py-1.5 text-sm rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-600"
    >
      {children}
    </button>
  );
}

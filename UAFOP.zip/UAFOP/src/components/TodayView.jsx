import { prettyDate, prettyTime, todayStr } from "../dateutils.js";

// Landing page: today's tasks, or an "all clear" message when there are none.
export default function TodayView({ tasks, onToggle, onDelete, onAdd }) {
  const today = todayStr();
  const todays = tasks
    .filter((t) => t.date === today)
    .sort((a, b) => (a.time || "99").localeCompare(b.time || "99"));

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Today</h2>
          <p className="text-slate-500">{prettyDate(today)}</p>
        </div>
        <button
          onClick={onAdd}
          className="bg-brand-600 hover:bg-brand-700 text-white font-medium px-4 py-2 rounded-lg shadow-sm"
        >
          + Add event
        </button>
      </div>

      <div className="mt-6 space-y-2">
        {todays.length === 0 ? (
          <div className="text-center bg-white border border-slate-200 rounded-2xl py-14 px-6">
            <div className="text-4xl">🎉</div>
            <p className="mt-3 text-lg font-medium text-slate-800">
              All tasks complete!
            </p>
            <p className="text-slate-500">Nothing left on your plate today.</p>
          </div>
        ) : (
          todays.map((t) => (
            <div
              key={t.id}
              className="flex items-center gap-3 bg-white border border-slate-200 rounded-xl px-4 py-3"
            >
              <input
                type="checkbox"
                checked={t.done}
                onChange={() => onToggle(t)}
                className="h-5 w-5 rounded accent-brand-600"
              />
              <div className="flex-1">
                <p
                  className={`font-medium ${
                    t.done ? "line-through text-slate-400" : "text-slate-800"
                  }`}
                >
                  {t.title}
                </p>
                {t.time && (
                  <p className="text-xs text-slate-400">{prettyTime(t.time)}</p>
                )}
              </div>
              <button
                onClick={() => onDelete(t)}
                className="text-slate-400 hover:text-red-500 text-sm"
                title="Remove"
              >
                Remove
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

import { useEffect, useRef, useState } from "react";
import { api, openChatSocket } from "../api.js";

// Role-based chat. Channels are created and joined automatically by the server
// (Family for everyone, Parents for parents), so we just list what this
// profile belongs to and stream messages over a WebSocket.
export default function ChatView({ profile }) {
  const [channels, setChannels] = useState([]);
  const [active, setActive] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const socketRef = useRef(null);
  const bottomRef = useRef(null);

  // Load channels once.
  useEffect(() => {
    api.channels(profile.id).then((d) => {
      setChannels(d.channels);
      if (d.channels[0]) setActive(d.channels[0].id);
    });
  }, [profile.id]);

  // Keep one socket open for the lifetime of the view.
  useEffect(() => {
    const ws = openChatSocket(profile.id);
    socketRef.current = ws;
    ws.onmessage = (ev) => {
      const data = JSON.parse(ev.data);
      if (data.type === "message") {
        setMessages((prev) =>
          // only append if it belongs to the channel we're viewing
          data.message.channelId === activeRef.current
            ? [...prev, data.message]
            : prev
        );
      }
    };
    return () => ws.close();
  }, [profile.id]);

  // activeRef mirrors `active` so the socket handler always sees the latest.
  const activeRef = useRef(active);
  useEffect(() => {
    activeRef.current = active;
  }, [active]);

  // Load history when switching channels.
  useEffect(() => {
    if (!active) return;
    api.messages(active).then((d) => setMessages(d.messages));
  }, [active]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  function send(e) {
    e.preventDefault();
    const body = text.trim();
    if (!body || !active) return;
    socketRef.current?.send(
      JSON.stringify({ type: "send", channelId: active, body })
    );
    setText("");
  }

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-9rem)] flex gap-4">
      {/* Channel list */}
      <div className="w-44 shrink-0 bg-white border border-slate-200 rounded-2xl p-2">
        <p className="px-2 py-1 text-xs font-semibold uppercase tracking-wide text-slate-400">
          Channels
        </p>
        {channels.map((c) => (
          <button
            key={c.id}
            onClick={() => setActive(c.id)}
            className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium ${
              active === c.id
                ? "bg-brand-50 text-brand-700"
                : "text-slate-600 hover:bg-slate-50"
            }`}
          >
            # {c.name}
          </button>
        ))}
      </div>

      {/* Conversation */}
      <div className="flex-1 flex flex-col bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.length === 0 && (
            <p className="text-center text-slate-400 text-sm mt-8">
              No messages yet. Say hello 👋
            </p>
          )}
          {messages.map((m) => {
            const mine = m.senderId === profile.id;
            return (
              <div
                key={m.id}
                className={`flex flex-col ${mine ? "items-end" : "items-start"}`}
              >
                {!mine && (
                  <span className="text-xs text-slate-400 ml-1 mb-0.5">
                    {m.senderName}
                    <span className="text-slate-300"> · {m.senderRole}</span>
                  </span>
                )}
                <div
                  className={`max-w-[75%] px-3 py-2 rounded-2xl text-sm ${
                    mine
                      ? "bg-brand-600 text-white rounded-br-sm"
                      : "bg-slate-100 text-slate-800 rounded-bl-sm"
                  }`}
                >
                  {m.body}
                </div>
              </div>
            );
          })}
          <div ref={bottomRef} />
        </div>

        <form onSubmit={send} className="border-t border-slate-200 p-3 flex gap-2">
          <input
            className="input"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={active ? "Message…" : "Select a channel"}
            disabled={!active}
          />
          <button
            type="submit"
            disabled={!active || !text.trim()}
            className="bg-brand-600 hover:bg-brand-700 text-white px-4 rounded-lg font-medium disabled:opacity-50"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
}

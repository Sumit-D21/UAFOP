// Thin REST client. All paths are same-origin so this works in dev (via the
// Vite proxy) and in production (served by Express).
async function req(method, path, body) {
  const res = await fetch(path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `${method} ${path} failed`);
  return data;
}

export const api = {
  register: (name, familyName) =>
    req("POST", "/api/register", { name, familyName }),
  addMember: (parentProfileId, name, role) =>
    req("POST", "/api/members", { parentProfileId, name, role }),
  join: (inviteCode) => req("POST", "/api/join", { inviteCode }),
  getProfile: (id) => req("GET", `/api/profile/${id}`),
  members: (familyId) => req("GET", `/api/family/${familyId}/members`),

  tasks: (profileId, date) =>
    req(
      "GET",
      `/api/tasks?profileId=${profileId}${date ? `&date=${date}` : ""}`
    ),
  addTask: (profileId, title, date, time) =>
    req("POST", "/api/tasks", { profileId, title, date, time }),
  updateTask: (id, patch) => req("PATCH", `/api/tasks/${id}`, patch),
  deleteTask: (id) => req("DELETE", `/api/tasks/${id}`),

  channels: (profileId) => req("GET", `/api/channels?profileId=${profileId}`),
  messages: (channelId) => req("GET", `/api/channels/${channelId}/messages`),
};

// Open a chat WebSocket for a profile. Resolves the same-origin ws URL.
export function openChatSocket(profileId) {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  return new WebSocket(`${proto}://${location.host}/ws?profileId=${profileId}`);
}

import { useCallback, useEffect, useState } from "react";
import { api } from "./api.js";
import Onboarding from "./components/Onboarding.jsx";
import TodayView from "./components/TodayView.jsx";
import CalendarView from "./components/CalendarView.jsx";
import ChatView from "./components/ChatView.jsx";
import MembersView from "./components/MembersView.jsx";
import AddEventModal from "./components/AddEventModal.jsx";

const SESSION_KEY = "sp_profileId";

export default function App() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("today");
  const [tasks, setTasks] = useState([]);
  const [adding, setAdding] = useState(null); // null | { date }

  // Restore session from a previous visit.
  useEffect(() => {
    const id = localStorage.getItem(SESSION_KEY);
    if (!id) {
      setLoading(false);
      return;
    }
    api
      .getProfile(id)
      .then((d) => setProfile(d.profile))
      .catch(() => localStorage.removeItem(SESSION_KEY))
      .finally(() => setLoading(false));
  }, []);

  function onReady(p) {
    localStorage.setItem(SESSION_KEY, p.id);
    setProfile(p);
  }

  function signOut() {
    localStorage.removeItem(SESSION_KEY);
    setProfile(null);
    setTasks([]);
    setTab("today");
  }

  // Single source of truth for tasks — Today and Calendar both read this, so
  // any add/remove keeps them in lockstep.
  const loadTasks = useCallback(() => {
    if (!profile) return;
    api.tasks(profile.id).then((d) => setTasks(d.tasks));
  }, [profile]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  async function saveTask({ title, date, time }) {
    await api.addTask(profile.id, title, date, time);
    setAdding(null);
    loadTasks();
  }
  async function toggleTask(t) {
    await api.updateTask(t.id, { done: !t.done });
    loadTasks();
  }
  async function deleteTask(t) {
    await api.deleteTask(t.id);
    loadTasks();
  }

  if (loading)
    return (
      <div className="min-h-full grid place-items-center text-slate-400">
        Loading…
      </div>
    );

  if (!profile) return <Onboarding onReady={onReady} />;

  const tabs = [
    ["today", "Today"],
    ["calendar", "Calendar"],
    ["chat", "Chat"],
    ...(profile.role === "parent" ? [["family", "Family"]] : []),
  ];

  return (
    <div className="min-h-full">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="font-bold text-slate-900">Smart Planner</span>
            <nav className="flex gap-1">
              {tabs.map(([id, label]) => (
                <button
                  key={id}
                  onClick={() => setTab(id)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium ${
                    tab === id
                      ? "bg-brand-50 text-brand-700"
                      : "text-slate-500 hover:bg-slate-50"
                  }`}
                >
                  {label}
                </button>
              ))}
            </nav>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <span className="text-slate-500">
              {profile.name}
              <span className="text-slate-300"> · {profile.role}</span>
            </span>
            <button
              onClick={signOut}
              className="text-slate-400 hover:text-slate-600"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6">
        {tab === "today" && (
          <TodayView
            tasks={tasks}
            onToggle={toggleTask}
            onDelete={deleteTask}
            onAdd={() => setAdding({ date: null })}
          />
        )}
        {tab === "calendar" && (
          <CalendarView
            tasks={tasks}
            onAddOnDate={(date) => setAdding({ date })}
            onToggle={toggleTask}
            onDelete={deleteTask}
          />
        )}
        {tab === "chat" && <ChatView profile={profile} />}
        {tab === "family" && <MembersView profile={profile} />}
      </main>

      {adding && (
        <AddEventModal
          defaultDate={adding.date}
          onClose={() => setAdding(null)}
          onSave={saveTask}
        />
      )}
    </div>
  );
}
